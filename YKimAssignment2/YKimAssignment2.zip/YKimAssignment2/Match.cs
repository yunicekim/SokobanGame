﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YKimAssignment2
{
    class Match
    {
        public int Row { get; }
        public int Col { get; }

        public Match(int row, int col)
        {
            this.Row = row;
            this.Col = col;
        }

    }
}
